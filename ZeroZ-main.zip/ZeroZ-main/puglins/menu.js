// Plugin de menú principal del bot
// Comando: #menu, #help, #comandos

export default {
    async all(m) {
        const text = m.text?.trim() || '';

        // Verificar si es el comando de menú
        if (text === '#menu' || text === '#help' || text === '#comandos') {
            const user = m.pushName || 'Usuario';
            const botNumber = this.user.jid.split('@')[0];

            // Obtener tiempo de actividad del bot
            const uptime = process.uptime();
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor((uptime % 86400) / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const seconds = Math.floor(uptime % 60);

            const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

            // Construir el menú
            const menu = `╭━━━━━━━━━━━━━━━━━━━╮
┃  🤖 *MENÚ DEL BOT*
┃  👤 Usuario: ${user}
┃  📱 Bot: ${botNumber}
┃  ⏰ Activo: ${uptimeStr}
╰━━━━━━━━━━━━━━━━━━━╯

╭━━⬣ *COMANDOS BÁSICOS* ⬣━━╮
┃
┃  🏓 *#p*
┃  └ Verifica el estado del bot
┃
┃  📋 *#menu*
┃  └ Muestra este menú
┃
┃  ❓ *#help*
┃  └ Ayuda del bot
┃
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━⬣ *ADMINISTRACIÓN DE GRUPOS* ⬣━━╮
┃
┃  🔓 *#open*
┃  └ Abre el grupo para todos
┃  └ ⚠️ Solo admins
┃
┃  🔒 *#close*
┃  └ Cierra el grupo (solo admins)
┃  └ ⚠️ Solo admins
┃
╰━━━━━━━━━━━━━━━━━━━━╯

╭━━⬣ *INFORMACIÓN* ⬣━━╮
┃
┃  📌 Prefijos: # ! / .
┃  👑 Propietario: wa.me/50662158272
┃  🌐 GitHub: github.com/Zeroxx2007/ZeroZ
┃
╰━━━━━━━━━━━━━━━━━━━━╯

_Bot creado por Zero_`;

            // Enviar el menú
            await this.sendMessage(m.chat, {
                text: menu
            }, { quoted: m });
        }
    }
}
