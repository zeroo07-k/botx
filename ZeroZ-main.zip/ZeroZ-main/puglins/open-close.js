// Plugin para abrir/cerrar grupos
// Comandos: #open, #close

export default {
    async all(m) {
        // Solo procesar mensajes de grupo
        if (!m.isGroup) return;

        const text = m.text?.trim() || '';

        // Verificar si es el comando #open o #close
        if (text === '#open' || text === '#close') {
            const groupMetadata = await this.groupMetadata(m.chat).catch(_ => null);
            if (!groupMetadata) return;

            const participants = groupMetadata.participants || [];
            const botUser = participants.find(p => p.id === this.user.jid);
            const sender = participants.find(p => p.id === m.sender);

            // Verificar que el bot sea admin
            const isBotAdmin = botUser?.admin === 'admin' || botUser?.admin === 'superadmin';
            if (!isBotAdmin) {
                await this.sendMessage(m.chat, {
                    text: '❌ Necesito ser administrador para cambiar la configuración del grupo.'
                }, { quoted: m });
                return;
            }

            // Verificar que el usuario sea admin
            const isUserAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';
            if (!isUserAdmin) {
                await this.sendMessage(m.chat, {
                    text: '❌ Solo los administradores pueden usar este comando.'
                }, { quoted: m });
                return;
            }

            try {
                if (text === '#open') {
                    // Abrir grupo - permitir que todos envíen mensajes
                    await this.groupSettingUpdate(m.chat, 'not_announcement');
                    await this.sendMessage(m.chat, {
                        text: '✅ Grupo abierto\n\n📢 Ahora todos los participantes pueden enviar mensajes.'
                    }, { quoted: m });
                } else if (text === '#close') {
                    // Cerrar grupo - solo admins pueden enviar mensajes
                    await this.groupSettingUpdate(m.chat, 'announcement');
                    await this.sendMessage(m.chat, {
                        text: '🔒 Grupo cerrado\n\n⚠️ Solo los administradores pueden enviar mensajes.'
                    }, { quoted: m });
                }
            } catch (error) {
                console.error('Error al cambiar configuración del grupo:', error);
                await this.sendMessage(m.chat, {
                    text: `❌ Error al cambiar la configuración del grupo:\n${error.message}`
                }, { quoted: m });
            }
        }
    }
}
